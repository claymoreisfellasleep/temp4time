package clay.more.models;

public class ApplicationRequest {
    Long id;
    String userName;
    String courseName;
    String commentary;
    String phone;
    boolean handled;
}
